import { NextRequest } from "next/server";

import { success } from "@/lib/api-response";
import { apiError } from "@/lib/api-error";

export async function POST(
  request: NextRequest
) {
  try {
    /**
     * TODO
     * Destroy Session
     * Remove Cookies
     * Audit Log
     */

    return success(
      null,
      "Logout successful."
    );
  } catch (error) {
    return apiError(error);
  }
}