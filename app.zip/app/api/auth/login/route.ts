import { NextRequest } from "next/server";

import { authService } from "@/lib/auth/auth";
import { success, failure } from "@/lib/api-response";
import { apiError } from "@/lib/api-error";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body.email || !body.password) {
      return failure(
        "Email and password are required.",
        400
      );
    }

    const result = await authService.login({
      email: body.email,
      password: body.password,
      rememberMe: body.rememberMe ?? false,
    });

    return success(result, "Login successful.");
  } catch (error) {
    return apiError(error);
  }
}