import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  try {
    const driverId = req.nextUrl.searchParams.get("driverId");

    const bookings = await prisma.booking.findMany({
      where: {
        driverId: driverId || "",
      },
      include: {
        customer: true,
        vehicle: true,
      },
      orderBy: {
        pickupDateTime: "asc",
      },
    });

    return NextResponse.json({
      success: true,
      data: bookings,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        success: false,
        message: "Failed.",
      },
      {
        status: 500,
      }
    );
  }
}