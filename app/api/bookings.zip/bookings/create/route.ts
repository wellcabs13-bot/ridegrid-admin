import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const {
      customerId,
      vendorId,
      vehicleId,
      driverId,
      pickupLocation,
      dropLocation,
      pickupDateTime,
      estimatedFare,
    } = body;

    const booking = await prisma.booking.create({
      data: {
        customerId,
        vendorId,
        vehicleId,
        driverId: driverId || null,
        pickupLocation,
        dropLocation,
        pickupDateTime: new Date(pickupDateTime),
        estimatedFare,
      },
    });

    await prisma.bookingStatusHistory.create({
      data: {
        bookingId: booking.id,
        currentStatus: "PENDING",
        action: "CREATED",
      },
    });

    return NextResponse.json({
      success: true,
      data: booking,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        success: false,
        message: "Booking creation failed",
      },
      { status: 500 }
    );
  }
}