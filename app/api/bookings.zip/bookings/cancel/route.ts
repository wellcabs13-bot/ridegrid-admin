import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const { bookingId, reason, cancelledBy } = await req.json();

    const booking = await prisma.booking.update({
      where: {
        id: bookingId,
      },
      data: {
        status: "CANCELLED",
        cancelReason: reason,
        cancelledBy,
        cancelledAt: new Date(),
      },
    });

    await prisma.bookingStatusHistory.create({
      data: {
        bookingId,
        currentStatus: "CANCELLED",
        action: "CANCELLED",
      },
    });

    return NextResponse.json({
      success: true,
      data: booking,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        success: false,
        message: "Booking cancellation failed.",
      },
      {
        status: 500,
      }
    );
  }
}